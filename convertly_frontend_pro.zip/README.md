# Convertly — Frontend Pro

Convertly Frontend Pro is a privacy-first, browser-only file converter built for global users. Everything runs locally in the user's browser — files are never uploaded.

## Features
- PDF → PNG (each page exported to PNG and delivered as a ZIP)
- PDF → TXT (text extraction)
- JPG ↔ PNG
- TXT → PDF
- PNG → WebP
- DOCX → TXT (experimental using mammoth.js)

## How to use
1. Extract the ZIP and open `index.html` in a modern browser (Chrome, Edge, Firefox).
2. Choose a file and conversion type, then click Convert.

## Deployment (Vercel)
1. Create a GitHub repo and push the project files (`index.html`, `static/`, `README.md`).
2. Go to https://vercel.com → New Project → Import GitHub Repo → Select repo → Deploy.

No server or backend required.

## Notes
- Large PDFs or images may be memory-intensive on low-end devices.
- DOCX → TXT is experimental and may not perfectly preserve formatting.
- For server-side, high-fidelity conversions consider adding a backend with LibreOffice or unoconv.
