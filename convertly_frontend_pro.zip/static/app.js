
const fileInput = document.getElementById('file');
const fname = document.getElementById('fname');
const actionSel = document.getElementById('action');
const convertBtn = document.getElementById('convert');
const status = document.getElementById('status');
const result = document.getElementById('result');
const filebox = document.getElementById('filebox');

let file = null;

fileInput.addEventListener('change', (e) => {
  if (e.target.files.length) {
    file = e.target.files[0];
    fname.textContent = file.name;
    result.innerHTML = '';
    status.textContent = 'Ready';
  }
});

filebox.addEventListener('dragover', (e) => { e.preventDefault(); filebox.style.borderColor = '#4f46e5'; });
filebox.addEventListener('dragleave', (e) => { filebox.style.borderColor = ''; });
filebox.addEventListener('drop', (e) => {
  e.preventDefault(); filebox.style.borderColor = '';
  if (e.dataTransfer.files.length) {
    file = e.dataTransfer.files[0];
    fname.textContent = file.name;
    fileInput.files = e.dataTransfer.files;
    result.innerHTML = '';
    status.textContent = 'Ready';
  }
});

convertBtn.addEventListener('click', async () => {
  if (!file) { alert('Please choose a file first'); return; }
  const action = actionSel.value;
  status.textContent = 'Processing...';
  result.innerHTML = '';

  try {
    if (action === 'jpg-to-png' || action === 'png-to-jpg') {
      await imageConvert(file, action);
    } else if (action === 'txt-to-pdf') {
      await txtToPdf(file);
    } else if (action === 'pdf-to-txt') {
      await pdfToTxt(file);
    } else if (action === 'pdf-to-png') {
      await pdfToPng(file);
    } else if (action === 'png-to-webp') {
      await pngToWebp(file);
    } else if (action === 'docx-to-txt') {
      await docxToTxt(file);
    }
    status.textContent = 'Done';
  } catch (e) {
    console.error(e);
    status.textContent = 'Error: ' + e.message;
    result.innerHTML = '<div style="color:#ffb4b4">Error: ' + e.message + '</div>';
  }
});

// helpers
function loadImageFromFile(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = reject;
    img.src = url;
  });
}

async function imageConvert(file, action) {
  const img = await loadImageFromFile(file);
  const canvas = document.createElement('canvas');
  canvas.width = img.width;
  canvas.height = img.height;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img, 0, 0);

  if (action === 'jpg-to-png') {
    canvas.toBlob((blob) => {
      downloadBlob(blob, replaceExt(file.name, 'png'));
    }, 'image/png');
  } else {
    canvas.toBlob((blob) => {
      downloadBlob(blob, replaceExt(file.name, 'jpg'));
    }, 'image/jpeg', 0.92);
  }
}

// TXT -> PDF using jsPDF
async function txtToPdf(file) {
  const text = await file.text();
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const lines = doc.splitTextToSize(text, 180);
  let y = 20;
  for (let i = 0; i < lines.length; i++) {
    if (y > 280) { doc.addPage(); y = 20; }
    doc.text(lines[i], 15, y);
    y += 8;
  }
  const blob = doc.output('blob');
  downloadBlob(blob, replaceExt(file.name, 'pdf'));
}

// PDF -> TXT using PDF.js
async function pdfToTxt(file) {
  const arrayBuf = await file.arrayBuffer();
  const loadingTask = pdfjsLib.getDocument({data: arrayBuf});
  const pdf = await loadingTask.promise;
  let fullText = '';
  for (let p = 1; p <= pdf.numPages; p++) {
    const page = await pdf.getPage(p);
    const textContent = await page.getTextContent();
    const strings = textContent.items.map(i => i.str);
    fullText += strings.join(' ') + '\n\n';
  }
  const blob = new Blob([fullText], {type: 'text/plain'});
  downloadBlob(blob, replaceExt(file.name, 'txt'));
}

// PDF -> PNG: render each page to canvas, zip pages
async function pdfToPng(file) {
  const arrayBuf = await file.arrayBuffer();
  const loadingTask = pdfjsLib.getDocument({data: arrayBuf});
  const pdf = await loadingTask.promise;
  const zip = new JSZip();
  for (let p = 1; p <= pdf.numPages; p++) {
    const page = await pdf.getPage(p);
    const viewport = page.getViewport({scale: 2}); // higher res
    const canvas = document.createElement('canvas');
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const ctx = canvas.getContext('2d');
    await page.render({canvasContext: ctx, viewport: viewport}).promise;
    const blob = await new Promise(res => canvas.toBlob(res, 'image/png'));
    zip.file('page-' + p + '.png', blob);
  }
  const content = await zip.generateAsync({type:'blob'});
  saveAs(content, replaceExt(file.name, 'pages.zip'));
}

// PNG -> WebP
async function pngToWebp(file) {
  const img = await loadImageFromFile(file);
  const canvas = document.createElement('canvas');
  canvas.width = img.width;
  canvas.height = img.height;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img, 0, 0);
  canvas.toBlob((blob) => {
    downloadBlob(blob, replaceExt(file.name, 'webp'));
  }, 'image/webp', 0.9);
}

// DOCX -> TXT using mammoth.js (experimental)
async function docxToTxt(file) {
  const arrayBuf = await file.arrayBuffer();
  const result = await mammoth.extractRawText({arrayBuffer: arrayBuf});
  const text = result.value || '';
  const blob = new Blob([text], {type: 'text/plain'});
  downloadBlob(blob, replaceExt(file.name, 'txt'));
}

function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000 * 10);
}

function replaceExt(name, ext) {
  const base = name.replace(/\.[^.]+$/, '');
  return base + '.' + ext;
}
